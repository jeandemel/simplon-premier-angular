import { Component } from '@angular/core';


@Component({
    selector: 'mon-app',
    template: `<router-outlet></router-outlet>`
    //afficher les 2 attributs dans le template
})
export class AppComponent {
    
}