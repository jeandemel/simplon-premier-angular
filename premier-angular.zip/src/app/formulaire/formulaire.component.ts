import { Component, OnInit } from '@angular/core';
import { Utilisateur } from '../shared/utilisateur';

@Component({
  selector: 'app-formulaire',
  templateUrl: './formulaire.component.html',
  styleUrls: ['./formulaire.component.css']
})
export class FormulaireComponent implements OnInit {
  nouvelUtilisateur:Utilisateur;
  mdp2:string;

  constructor() {
    this.nouvelUtilisateur = new Utilisateur();
   }

  ngOnInit() {
  }

  inscription(): void {
    console.log(this.nouvelUtilisateur);
    console.log(this.mdp2);
  }
}
