

export class Utilisateur {
    _id:string;
    nom: string;
    prenom: string;
    mdp: string;
    email: string;
}